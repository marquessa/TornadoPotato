This is a low poly style model pack of a farm tractor and a planter.

Textures up to 2048x2048. 
Prefabs and showcase scene included.
Meshes comes in .fbx format, textures .tga.

Meshs Triangle count:
Tractor:
	LOD0: 1240
Planter:
	LOD0: 9218
	LOD1: 7486

Attention!
The example scene uses Unity's standard assets packages such as Characters,Environments, Image Effects and Particle Systems. Please load them for it to work correctly.
Please remember to use Linear color space when working with PBR Assets. You can change this in your Unity's Player settings.